.. _user:

.. include:: ../README.rst
